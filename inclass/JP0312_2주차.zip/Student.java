package project0312;

public class Student {
	// 1. �Ӽ�, �ʵ�, ��������
	private String name;
	private int stuld;
	private int age;
	
	// 2. ������
	Student(){}
	Student(String name, int stuld, int age){
		this.name = name;
		this.stuld = stuld;
		this.age = age;
	}
	
	// 3. ����, ��� 
	String getName(String name) {
		return name;
	}
	
	int getStuld(int stuld) {
		return stuld;
	}
	
	int getAge(int age) {
		return age;
	}
	
	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public int getStuld() {
		return stuld;
	}




	public void setStuld(int stuld) {
		this.stuld = stuld;
	}




	public int getAge() {
		return age;
	}




	public void setAge(int age) {
		this.age = age;
	}




	
	
	
}
