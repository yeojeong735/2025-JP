package project0312;

public class Exeam06 {

	public static void main(String[] args) {
		try {
			int num1 = 100, num2 = 0;
			System.out.println(num1/num2);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("��꿡 ������ �ֽ��ϴ�.");
		}
	}

}
