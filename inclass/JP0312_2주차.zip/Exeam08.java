package project0312;

public class Exeam08 {

	public static void main(String[] args) {
		Student student1 = new Student("one",20241111,21);
		Student student2 = new Student("two",20252222,20); 
		
		System.out.println(student1.getName());
		System.out.println(student1.getAge());
		System.out.println(student1.getStuld());
		
		System.out.println(student2.getName());
		System.out.println(student2.getAge());
		System.out.println(student2.getStuld());
	}
	
	

}
