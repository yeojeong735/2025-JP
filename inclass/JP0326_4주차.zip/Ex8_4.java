package inclass;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Ex8_4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			FileWriter fout = new FileWriter("E:\\test\\test2.txt");
			while(true) {
				String line = sc.nextLine();
				if(line.length() == 0) {
					System.out.println("이제 그만");
					break;
				}
				System.out.println(line + "\n");
				fout.write(line,0,line.length());
				fout.write("\r\n",0,2);
			}
			fout.close();
		}catch(IOException e){
			e.printStackTrace();
			System.out.println("IO 에러 발생");
		}
		
		

	}

}
