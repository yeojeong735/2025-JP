package inclass;

import java.util.*;

public class Ex8_2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("당신의 이름을 입력하시오.");
		String name = sc.nextLine();
		
		System.out.println("당신의 나이를 입력하시오.");
		int age = sc.nextInt();
		
		System.out.println("안녕하세요. " + name + "님의 나이는 " + age + "입니다.");
		
	}

}
