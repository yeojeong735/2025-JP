package inclass;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class UserMain extends ArrayListEx1{

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		ArrayList<User> userList = new ArrayList<User>();
		String outputFile = "E:\\test\\UserOutput.txt";
		
		while(true) {
			System.out.println("이름을 입력하세요 (그만 입력 시 종료)");
			String name = scanner.nextLine();
			if(name.equals("그만")) {
				break;
			}
			System.out.println("나이를 입력하세요: ");
			int age = scanner.nextInt();
			scanner.nextLine();
			
			User user1 = new User(name, age);
			userList.add(user1);
		}
		
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
			for (User user : userList) {
                writer.write(user.toString());
                writer.newLine();
            }
            writer.close();
            System.out.println("사용자 정보가 " + outputFile + " 파일에 저장되었습니다.");
        } catch (IOException e) {
            System.out.println("파일 저장 중 오류 발생: " + e.getMessage());
        }
        
        scanner.close();

	}

}
