package inclass;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class Ex8_9 {

	public static void main(String[] args) {
		try {
			//File src = new File(" "); // 원본 파일 경로명
			File dest = new File("E:\\test\\test2.txt");
			String src = "E:\\test\\test3.txt";
			
			FileReader fr = new FileReader(src);
			BufferedReader bin = new BufferedReader(fr);
			BufferedWriter bout = new BufferedWriter(new FileWriter(dest));
			//FileWriter fw = new FileWriter(dest);
			
			int c;
			while((c = bin.read()) != -1) {
				bout.write((char)c);
			}
			
			fr.close();
			bin.close();
			System.out.println(src + "파일 복사 완료" + dest.getPath());
			
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("파일 복사 에러~~");
		}

	}

}
