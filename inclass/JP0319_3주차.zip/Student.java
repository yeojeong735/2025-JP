package pro0319;

public class Student extends Person implements PrintInterface{
	protected int stuld;
	protected String jeongong;
	
	Student(){}
	Student(String name, String adress, int phone, int stuld, String jeongong){
		super(name, adress, phone);
		this.stuld = stuld;
		this.jeongong = jeongong;
	}
	
	
	@Override
	public void print() {
		System.out.println("�̸� : "+ name);
		System.out.println("�ּ� : "+ adress);
		System.out.println("���� : "+ phone);
		System.out.println("�й� : "+ stuld);
		System.out.println("���� : "+ jeongong);
		
	}
	
	
	public int getStuld() {
		return stuld;
	}
	public void setStuld(int stuld) {
		this.stuld = stuld;
	}
	public String getJeongong() {
		return jeongong;
	}
	public void setJeongong(String jeongong) {
		this.jeongong = jeongong;
	}
	
	
	
}
