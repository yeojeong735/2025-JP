package pro0319;

public interface IAnimal {
	abstract void eat(); //abstract
}
