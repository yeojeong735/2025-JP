package pro0319;

public class Person {
	protected String name;
	protected String adress;
	protected int phone;
	
	
	
	Person(){}
	Person(String name, String adress, int phone){
		this.name = name;
		this.adress = adress;
		this.phone = phone;
	}
	
	
	
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	
	
}
