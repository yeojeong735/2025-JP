package pro0319;
class ICat implements IAnimal{

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("������ �����Ѵ�.");
	}
	
}
//
class ITiger extends Animal implements IAnimal{

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("������� ��ƸԴ´�.");
	}

	@Override
	void move() {
		// TODO Auto-generated method stub
		System.out.println("4�߷� �ɾ�ٴѴ�.");
	}
	
}

//
public class exam12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ICat cat1 = new ICat();
		cat1.eat();
		
		ITiger tig1 = new ITiger();
		tig1.eat();
		tig1.move();
	}

}
