package pro0319;

public interface PrintInterface {
	void print();
}
